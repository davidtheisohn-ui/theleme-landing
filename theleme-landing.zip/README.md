# Theleme Landing (React + Vite + Tailwind)

## StackBlitz
- Ouvrez https://stackblitz.com/
- Glissez-déposez `theleme-landing.zip`
- Le preview démarre automatiquement

## Local
```bash
npm install
npm run dev
```

## Personnaliser
- Palette : `src/index.css`
- Contenu : `src/App.jsx`
